from flask import Flask, render_template, jsonify

app = Flask(__name__)


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/api/menu")
def menu():
    return jsonify({
        "restaurant": "Огуз Хан",
        "type": "Домашняя кухня",
        "status": "open",
        "dishes": [
            "Плов",
            "Манты",
            "Лагман",
            "Шашлык",
            "Самса"
        ]
    })


@app.route("/api/about")
def about():
    return jsonify({
        "name": "Огуз Хан",
        "description": "Ресторан домашней кухни",
        "message": "Добро пожаловать!"
    })


if __name__ == "__main__":
    app.run(debug=True, port=5002)